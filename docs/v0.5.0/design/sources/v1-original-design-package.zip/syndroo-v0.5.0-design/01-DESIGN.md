# Syndroo 0.5.0 — 可靠性、授权闭环与架构优化设计

- 文档版本：1.0；日期：2026-09-21（Asia/Tokyo）。
- 状态：**待评审设计规格；不是已实施、已测试或已发布的版本**。
- 用户已确认：推荐 B 范围，并要求合理抽象、设计模式及可维护性优化。
- 本轮交付：本会话文件；不修改源码、不执行迁移、不发布、不部署、不调用真实 SNS。
- 基线：`main@d8206f298333eeb83d45d319ea244bbda72c78f7`。本轮重新读取关键源码；此前复现结果是历史证据，不是本轮重跑结果。
- 规范层级：本文件定义产品与行为；[架构决策](02-ARCHITECTURE-DECISIONS.md)解释取舍；[验收矩阵](03-ACCEPTANCE.md)定义证据；[交接说明](04-HANDOFF.md)仅提供后续实施准备。

## 1. 版本目标与边界

### 1.1 要交付什么

0.5.0 是一个可靠性和授权完整版本，而不是平台数量扩张版。主要用户仍是单用户自托管的开发者、创作者和通过 Skill/CLI 操作的 Agent。

完成下面这条链路，并在每一步给出真实、可恢复的结果：

```text
配置实例 → 配置/连接平台 → 确认目标 → 校验内容
    → 创建任务（稳定幂等键）→ Queue/Cron 执行
    → 查询每个平台的结果 → 故障后按确定性恢复
```

**必须包含：**六项审查缺陷；统一凭据解析；OAuth 输入、网络、state 和刷新并发保护；连接变更与旧任务隔离；SDK/CLI/Skill 授权操作；必要的增量数据迁移；对应本地集成、安装产物测试；文档、版本及 release-train 准备。

**明确不包含：**新 SNS 平台、媒体/长文新能力、UI、多租户、多账户产品、团队权限、通用插件市场、完整凭据加密/自动密钥轮换系统、调度吞吐扩容、指标平台。也不把真实发布或生产变更授权包含在设计内。

“没有多账户产品”不等于“忽略换号”：每个平台仍只有一个有效凭据槽位，但任务必须绑定当时确认的连接，不能跟随槽位中的新账号。

### 1.2 稳定性优先级

优先顺序是：不误发/不重复发 > 不丢失可恢复的本地工作 > 准确报告 > 正常路径速度 > 代码行数。Ponytail 用来删掉无收益复杂度，不删除输入验证、并发保护或必要回归测试。

本次采用“保留现有模块化单体，优化真实边界”。不是只打补丁，也不是重建 Clean Architecture 框架。备选方案与不采用的理由见 ADR-050-01。

## 2. 当前问题到设计的映射

以下位置均相对上述提交；完整依据见 [基线与来源](05-SOURCES-AND-BASELINE.md)。

| 问题 | 当前代码依据 | 0.5.0 的决策 |
|---|---|---|
| D1 授权后仍被创建准入拒绝 | `posts.ts:160–181`；`publishers.ts:9–25` | 请求结构解析不读取配置；准入/状态/执行使用同一个 resolver |
| 三个平台使用当前本地 workerd 拒绝的 redirect 参数 | `x/src/index.ts:32–38`；Tumblr `76–81`；LinkedIn `47–58` | 统一 `manual`，原生 fetch + 出站边界测试，不靠 fetch mock 证明兼容 |
| 凭据读取故障误判为远程发布不确定 | `publishing.ts:43–74,180–190` | 准备在 claim 前完成；准备、调用、落库分开处理 |
| 异常 2xx receipt 丢失写入不确定性 | `sdk/src/types.ts:139–146` | 所有解析层必须透传 status/operation/应用可能性上下文 |
| LinkedIn callback 覆盖目标元数据 | `auth.ts:405–417` | callback 产生候选结果；确认目标后才原子激活；refresh 不整条替换 |
| SDK 独立进程等待提前结束 | `sdk/src/client.ts:545–577` | 活跃 wait 的 timer 默认保持进程存活；完成/中止后确定清理 |
| 同一平台配置存在多个不同结论 | `platform-descriptors.ts:51–80` | 一个解析结果，多个只读投影，不维护三套 Boolean 判断 |
| 领取、重连、刷新存在交错窗口 | `repository.ts:207–284,365–437` | 快照版本、事务条件更新、领取令牌、刷新前互斥 |

这里的 workerd 结论只对应历史实际复现的依赖组合。当前公开 Request 文档列举的参数与该本地运行时表现并不完全一致；设计选择 `manual`，不宣称所有 Cloudflare 版本均不支持 `error`。[E1]

## 3. 架构与合理抽象

### 3.1 逻辑依赖方向

```text
Skill → CLI → public SDK → HTTP API
                              │
                   Worker application functions
                   ├─ post admission / auth lifecycle
                   ├─ publication executor / retry policy
                   └─ concrete D1Repository + Queue/Cron adapters
                              │
                   static platform definitions
                              │
               platform adapters → core contracts
                        │
              private transport helpers
```

`core` 不依赖 Worker、D1、Queue、平台适配器或网络工具包。SDK 不依赖私有 domain/adapter 包。新私有 transport 包不得反向导入任何平台或 Worker；它只是共享请求防护，不是新的业务层。

### 3.2 采用哪些模式，解决什么问题

| 机制 | 具体责任 | 停止抽象的位置 |
|---|---|---|
| Adapter + Strategy | 五个平台各自转换请求、解析结果、判断平台错误 | 保留一个 `Publisher.publish()`；没有 BasePublisher 继承树 |
| 简单静态 Factory/组合根 | 从已解析的平台配置构造正确 Publisher | 普通函数/固定映射；无运行时注册、动态扫描、DI 容器 |
| Application Service | `createPost`、授权生命周期、`executePublication` 各自编排副作用 | 函数即可；不建设 Service/Manager/UseCase 三层同义转发 |
| 显式状态机 + 判别联合 | 表达允许的发布/授权状态和错误阶段 | 转移规则 + SQL guard；不引入状态机框架或每状态一个类 |
| Repository + 条件事务 | 集中 D1 的领取、版本检查、状态聚合和原子提交 | 一个具体 D1Repository；不加 ORM、泛型 BaseRepository/UnitOfWork |
| Transactional Outbox + 幂等消费 | D1 保存意图，Queue 负责投递，Cron 恢复漏投 | 复用 publication 记录；不新增事件总线或通用 outbox 表 |
| Facade | SDK 给 CLI/Agent 提供稳定的 posts/auth 接口 | 薄客户端，不复制服务器策略、不自动重试写操作 |

Outbox 与领取保证的是可恢复意图和重复投递控制，不是跨 D1 与外部 SNS 的 exactly-once。Queues 的 at-least-once 语义仍需处理重复消息。[E3]

### 3.3 建议文件边界

下面是职责归属，不要求为每个名词建立一个目录或类。

| 位置 | 职责与调整 |
|---|---|
| `packages/core/src/index.ts` | 保留平台、Post、Publication、Publisher、PublishError；仅补充真正共享的领域类型 |
| `packages/<platform>/src/` | 导出平台自己的 typed credential；纯字段验证/内容规则；Provider Adapter |
| `packages/transport/`（新、私有） | 有界请求/响应与严格 OAuth1 签名工具；无平台业务、无自动重试、无日志 |
| Worker `platform-descriptors.ts` | 固定安装清单、Env 映射及每平台 typed strategy；不作为万能 service |
| Worker `credentials.ts`（新） | 一次读快照、统一解析、公开状态脱敏投影、binding 计算 |
| Worker `auth.ts` | 路由、HTTP 参数/结果映射；OAuth1/2 协议步骤拆到邻近模块 |
| Worker `auth-operations.ts`（新） | 候选授权、确认激活、refresh 生命周期；不处理发布 |
| Worker `posts.ts` | 纯结构校验与创建编排分离；幂等重放不依赖当前平台配置 |
| Worker `publishing.ts` / `retry.ts` | 有明确阶段的执行流程、重试决策；不直接操作 Queue message |
| Worker `repository.ts` | 具体 SQL/事务；字段映射可在有阅读收益时拆文件，不按实体机械拆多个 repository |
| SDK `client.ts`、新增 `auth.ts`/`auth-types.ts` | posts 与 auth 的公共门面；复用现有传输，不依赖私有 transport 包 |
| CLI `commands/auth.ts` | 授权命令、确认、JSON 输出和凭据保护；复用原有参数/Reporter 机制 |

新增私有包的理由是已经存在的多个独立 adapter 和 OAuth 请求都需要同样的传输保护。它使用现有 Web 标准能力，不引入第三方 HTTP 客户端。必须接入 root build、workspace 依赖、bundle、许可证与包产物校验；私有模块不能成为 SDK/CLI 安装时需要下载的内部包。

## 4. 统一凭据解析与状态

### 4.1 唯一事实来源

`resolvePlatformCredential(platform, snapshot, env, now)` 负责合并合法来源、解析字段、验证目标格式与已知过期时间，返回 ready 或 blocked。它是纯逻辑，时间作为显式参数，不请求平台、不写 D1。

结构示意（设计契约，不是可直接覆盖的源码）：

```ts
type CredentialResolution<C> =
  | { kind: "ready"; credential: C; summary: SafePlatformStatus; snapshot: BindingSnapshot }
  | { kind: "blocked"; reason: ConfigIssue; summary: SafePlatformStatus };
```

`C` 是平台自己的类型，不是贯穿系统的 `Record<string, string>`。通用 JSON 只存在于外部输入/持久化边界，随后必须 decode。动态平台分派在 Worker 内封装类型关联，禁止用 `as any` 或重复的运行时猜测掩盖关联错误。

直接提交的 user credential 与最终合并后的 publishing credential 不是同一种输入：前者没有 Env app secret。可以有两个明确的 decoder，但底层字段规则必须复用，不能复制三套“配置完整”判断。

### 4.2 合并规则

1. 有有效 D1 凭据槽位时，用户凭据作为完整一组使用；不把 D1 access token 和 Env 的另一个 token secret 拼接。
2. X/Tumblr 的 app credentials 仍从 Env 获取；平台目标字段的允许 fallback 在 descriptor 中显式列举。
3. D1 中存在损坏、缺字段或已过期的凭据时，返回 blocked，不静默退回 Env 的另一个账号。
4. 没有 D1 用户凭据，或它已被显式删除时，可以按现有契约使用 Env。这个来源切换必须改变任务 binding。
5. 缺失 app secret、非法 blog/author/version、非法日期和非对象数据均是受控错误；不能变成无上下文的 TypeError/500。
6. `expires_at` 必须被读取和解释；未知 expiry 不冒充永不过期，不通过任意 truthiness 判断决定过期时间。

### 4.3 公开状态

继续保留既有 `configured`、`source`、`oauthSupported`。新增 `readiness`、`missingFields`、`expiresAt`、`revision` 和受保护的操作结果查询。

`readiness` 取 `ready | missing_credentials | needs_configuration | expired | reconnect_required | unavailable`。`configured` 是本地 readiness 为 ready 的兼容投影；不表示已对真实 SNS 验权。`source` 按实际被使用的来源计算为 `env | credential | mixed | null`，不是“Env 中恰好也有值”。

`configured=true`、成功存储、OAuth 拿到 token、真实发布成功是四个不同事实。状态不返回 token、password、client secret、refresh token、binding HMAC 或 OAuth state。

实例配置与平台配置分别报告：`GET /v1/auth` 增加 `instance: { publishingReady, missingFields }`，只返回缺少的配置名称。binding key 缺失/非法时，`publishingReady=false`，创建返回503/INSTANCE_NOT_READY，而不是把它伪装成某个平台未配置。`SYNDROO_PUBLIC_URL` 仅阻止OAuth启动，不阻止已正确配置的直接发布。新CLI doctor同时检查这两个层面。

## 5. 创建、幂等与发布状态机

### 5.1 创建顺序

沿用维护模式对 POST `/v1/posts` 的拒绝行为，GET 查询仍可使用：

```text
Bearer 验证 → 维护模式检查 → body 大小/JSON/结构校验
    → 查稳定 Idempotency-Key
       ├─ 已存在且内容相同：原 ID + replayed，不重新解析当前凭据
       ├─ 已存在且内容不同：409
       └─ 不存在：读取/解析全部平台凭据与 binding
                   → 单个 D1 事务创建 Post + Publications + key
                   → Queue send → 标记 enqueued
```

解析平台名与验证平台“当前已配置”必须分开。非法请求仍在数据库写入前拒绝；配置失败也不能创建部分 Post。并发唯一键冲突后必须读取原记录并比较 canonical request，而不是简单吞掉 SQL 错误。

transaction 中对 D1 凭据的 revision/删除状态做一致性条件检查，避免准入快照刚读完就被换号。条件不满足不是正常成功：不写入任何帖子，返回可识别的配置竞争结果；调用者仍保留原幂等键。

### 5.2 执行顺序：先准备，再领取，再调用

```text
读 Publication（终态可直接返回）
    → 读凭据快照、检查目标 binding、纯验证并构造 Publisher
    → 原子 claim：pending + 到期 + attempts<3 + snapshot revision 仍匹配
    → 用刚才构造的同一个 Publisher/不可变凭据快照调用平台
    → 带 claim token 保存结果、同时聚合 Post 状态
```

claim 前不执行任何 SNS 请求，包括 Bluesky session 建立。构造函数不得偷偷登录/刷新或启动定时器。claim 后不再重新解析“当前最新 token”，否则会重新打开换号竞态。

准备期 D1 短暂失败：不增加 attempts、不生成 ambiguous、不把工作终态化；请求 Queue retry，并在能安全写入时持久化基础设施 retry time。D1 完全不可用时依靠既有 pending/outbox 恢复，不谎称已写入 retry time。

已知永久配置错误、binding 不一致、legacy 未绑定：通过条件事务把待执行 publication 记录为 `failed/AUTH/errorAmbiguous=false`，保留 ID、内容和幂等记录，且平台请求数为零。错误消息是固定、脱敏、可解释的原因。没有自动重绑、自动换 key 或自动重新创建。

claim 本身失败：不能依据本地猜测调用平台。claim 未中选时，重新读取当前状态决定 ack/retry；旧快照禁止进入发布。

### 5.3 状态转移

保持公开 `PublicationStatus` 与 `PostStatus` 的已有值，不新增对外 preparing/retrying 状态。

| 当前状态 | 条件/事件 | 下一状态 | attempts/远程行为 |
|---|---|---|---|
| scheduled | 已到期，激活 CAS 成功 | pending | 不变；不请求平台 |
| pending | 准备期暂时失败 | pending | 不变；安排恢复 |
| pending | 永久配置/目标绑定错误 | failed | 不变；明确零平台请求 |
| pending | 到期且 claim 成功 | publishing | +1；获得随机 claim token |
| publishing | 确定成功，匹配领取令牌 | published | 原子写入平台凭据以外的结果信息 |
| publishing | 确定可重试且未到上限 | pending | 持久化 retry_at，再 retry delivery |
| publishing | 确定不可重试/上限达到 | failed | 不再自动发布 |
| publishing | 远程结果不确定 | failed + ambiguous | 禁止自动重发 |
| publishing | 15 分钟未保存结果，恢复事务中仍满足条件 | failed + ambiguous | 禁止把崩溃等同于未发出 |
| 任意终态 | 重复 Queue 消息 | 原状态 | 不调用平台 |

`attempts` 仍表示进入 Publisher 执行阶段的尝试次数，不声称等于 HTTP 请求条数；Bluesky 一次执行可能包含 session 和 publish 两个请求。D1 准备故障不消耗这个预算。

所有完成/失败更新带 `WHERE status='publishing' AND claim_token=?`。Scheduler 的 stale recovery 也必须重新检查状态和时间。late result 不覆盖已经恢复的终态；写脱敏诊断，留待人工核实。数据库事务失败不能只更新 Publication 而不更新父 Post。[E2]

### 5.4 重试边界

`retry.ts` 仍是唯一业务重试政策。SQL 只落实已决定的 retry time 和状态 guard，不复制另一份指数退避决策表。为 `markFailed` 统一提供显式 retry_at，去掉依赖 SQL 再算一次的双重规则。

保留最多三次 Publisher 执行。429/已知未写入的可用性错误可重试；发布阶段超时、连接中断、5xx 按保守 ambiguity 处理。HTTP wrapper、SDK 和官方 SNS SDK 不得再悄悄加一层写入重试。

“客户端创建请求可能被服务受理”和“某个平台可能已经发出”是两种 ambiguity，分别由 SDK 的 request outcome 与 Publication 的 `errorAmbiguous` 表达，不能混为一个 Boolean。

## 6. 连接绑定：保护旧定时任务，不建设多账户系统

### 6.1 两个不同的版本

- `revision`：凭据槽位的写入版本，用于 CAS，任何成功修改都递增；删除后保留不含凭据的 tombstone，避免删除再创建导致旧版本复活。
- `binding_id`：一次明确授权连接的随机标识。直接重新提交、重新授权完成、目标变更、删除都建立新 binding。只能在同一 refresh grant 的明确 token refresh 成功时保留。

每个平台仍只有一个 active slot。没有账户列表、跨账户路由或账户合并。

### 6.2 Publication binding

新增 publication 内部 `credential_binding`，由固定版本、固定字段顺序的输入元组经 WebCrypto HMAC-SHA-256 得出。使用独立实例 secret `SYNDROO_BINDING_KEY`（至少 32 字节随机值，采用明确编码）；不复用发布 Bearer key，避免普通 API key 轮换使所有定时任务失效。

- Env-only：元组包括 platform、来源、完整有效用户凭据、app credentials、目标配置。
- D1/mixed：元组包括 platform、binding_id、实际 app 配置、目标配置；受控 refresh 更新的用户 token 不进入这个稳定连接元组。
- 外部输入绝不能直接指定 binding 值；摘要仅存在内部存储与校验，不写日志或公开 DTO。

这是相等性/连接连续性检查，不是凭据加密，更不是对真实平台身份的证明。绑定 key 丢失/更换会让未完成任务需要显式复核；0.5.0 不实现多 key 自动轮换。这个新增 secret 是明确的升级前置条件，不得用默认值或缺失时跳过绑定。需要计算/校验binding的发布、connect、complete在key缺失时受控拒绝；状态查询及清除秘密的管理动作不能因缺key而泄露数据或失去可恢复性。

### 6.3 必须保持的边界

D1 更换凭据、D1→Env fallback、Env token/host/author/app 变化都会使旧任务不匹配。受控 refresh 只更新同一 grant 的 token，保留 binding_id 与目标元数据。无法证明属于原 refresh 操作时，不保留连接连续性。

正常 reauthorize 即使人眼看来是同一账号，也默认产生新 binding；本版不额外建设通用身份发现来推断同号。其旧任务不能静默续发，必须让用户重新确认。这是有意的安全/便利性取舍。

所有支持的D1凭据变更都必须经统一repository写入并更新revision/binding。具有直接数据库写权限的管理员绕过这些方法修改secret，不在应用级连续性保证之内；文档不推荐用裸SQL改token。

claim 前替换 D1 槽位：SQL revision guard 拒绝旧快照。claim 后替换：当前执行只持有旧快照，不能拿新账号发旧内容。删除/重连不是对已经发出的 HTTP 请求的撤销；界面、CLI 和文档必须说明这一点。

## 7. OAuth 与凭据生命周期

### 7.1 HTTP 路由和输入

保持现有基础路径；严格匹配路径段与方法，不接受多余后缀。除了精确列出的 OAuth callback，所有 `/v1/*` 仍要求 Bearer。body 保留 64 KiB 上限，新增 auth body decoder 拒绝 null、数组、基本类型与非法字段。

新增非秘密 `SYNDROO_PUBLIC_URL` 作为 OAuth 的 canonical HTTPS origin（仅启用 OAuth 时要求）；回调 URL 从它和已知平台路径生成，不采用请求方任意 Host/redirect 参数。测试使用明确隔离配置，不能让 loopback 测试例外进入生产默认。

### 7.2 授权是两阶段完成，不是 callback 自动覆盖

```text
Bearer connect → 保存 auth operation → 返回 provider URL + operationId
    → 浏览器授权 → callback 原子占用 state → 换取候选 token
    → 保存 awaiting_confirmation/needs_configuration
    → Bearer 读取脱敏候选信息 → 用户确认目标
    → Bearer complete + expected revision → 原子激活新连接
```

两阶段仅用于已有 OAuth1/2 授权，并非通用审批引擎。callback 不再直接覆盖 active credential，因此缺失 LinkedIn author 或 Tumblr blog 时不会破坏已有连接。0.5.0 将这一行为变更写入 release notes：旧的“回调成功即已激活”自动化需要升级。

沿用 `oauth_state` 表作为短期 operation 存储，增加不可预测的 `operation_id`、phase、期望槽位 revision、起始配置 binding、canonical callback 和候选数据。OAuth state 与 operationId 分离：读 operation 必须 Bearer；公开 callback 只接受匹配的 state，不因持有 operationId 获得权限。

对于需要的 author/blog，complete 必须获得明确选择或已验证的平台返回值；不静默继承旧账号的 author。可显示旧目标供用户重新选择，但“用户声明的目标”和“平台验证的身份”必须标注不同来源。LinkedIn API version 必须显式有效，不依靠藏在工厂中的魔法默认值。

### 7.3 state 约束

phase 为 `pending_callback → exchanging → awaiting_confirmation/needs_configuration → completed`，以及终态 `failed/expired`。TTL 从创建起算 30 分钟，不因轮询或重试自动续期。

callback 通过一次条件 `UPDATE … RETURNING` 抢占 `pending_callback`，同时检查平台、expiry、OAuth1 request token、起始配置仍有效；只有 winner 能换 token。若当前 D1 运行时的 RETURNING 支持不满足实现形式，应改成同事务内等价 CAS，不可退回 SELECT/DELETE 两次独立操作。[E2][E5]

state 与 request token 必须一致。OAuth1 严格 RFC 5849 编码/排序和固定请求范围，由共享、具测试向量的签名函数处理；不能只用裸 `encodeURIComponent` 代替规范编码。[E6]

OAuth2 使用现有保密客户端 authorization-code 方式。PKCE 的启用必须对应平台和 app 实际能力；不能把 LinkedIn 的受限原生 PKCE 文档当成 Worker callback 已普遍支持的证据。已证明支持的配置采用 S256；不支持的现有配置保留一次性 state、固定 callback、保密客户端认证及 Bearer complete，记录安全限制，不做静默协议降级。[E4][E7]

受鉴权的 connect 成功响应必须包含可打开的授权 URL，其中不可避免包含协议需要的短时 state/临时token参数；这是有限的交互输出例外，不是通用日志或status DTO的一部分。证据记录必须遮盖这些参数，不把完整URL放入持久日志。

callback 抢占后网络超时/进程崩溃，operation 不能自动重新兑换相同 code/verifier。过期 exchanging 标为失败并要求重新连接。complete 重复调用只重放该 operation 已保存的安全 receipt，不重复换取 token或重新覆盖后来的连接。

### 7.4 Token refresh 的并发安全

refresh 是写操作，不是普通 GET。不能先让两个请求都拿同一个 refresh token 请求平台，再仅靠落库 CAS 挑 winner。

必须先在 D1 获得该平台的 refresh lease，再执行一次外部兑换；并发 loser 返回 409/操作进行中，零外部请求。lease 含随机 token、开始时间与期望 revision。成功提交时匹配 lease 和 revision，原子更新 token/expiry，保留明确的目标元数据与 binding_id，并清理 lease。

无 refresh token 或平台不支持时，返回可执行的重新连接指引，不伪造可刷新能力。新响应没给 refresh token时保留旧值；明确空值/错误类型则作为无效 provider 响应处理。`expires_in` 的0表示立即到期，不是缺省；负值/非有限数/错误类型拒绝。没有新expiry且协议无可靠推导时标为未知，不把旧token的有效期无依据地套给新token，也不描述为永久有效。

refresh 请求结果不确定或崩溃超过安全期限时，不能简单释放锁然后重试可能已轮换的旧 refresh token。标记 `reconnect_required`，保留必要的脱敏诊断并阻止继续自动刷新。新的 direct set/complete/delete 可以取代这一状态；旧 refresh 的 late result 必须因 revision/lease 不匹配而被拒绝。[E4]

当前单用户实例沿用一个Bearer key管理发布和授权，因此该key本身具有敏感管理权限；本版不声称已实现细粒度权限。D1及候选令牌仍是应用层可读存储，必须限制数据库查询/导出/备份访问、规定保留期；候选到期及时清除，不声称删除历史备份中的秘密。完整应用层加密与key轮换不在B范围。

默认不在每次 publish 内自动 refresh，也不新增 Cron token 刷新服务。用户/Agent 可显式执行 refresh；未来自动刷新是独立需求。

### 7.5 最小必要 API 增量

| HTTP | 功能 | 重要结果 |
|---|---|---|
| `GET /v1/auth`、`GET /v1/auth/:platform` | 已有状态查询，扩展安全字段 | 本地 readiness 与 revision，不输出凭据 |
| `POST /v1/auth/:platform` | 已有直接凭据提交 | 完整校验后原子替换，绑定改变，200 |
| `DELETE /v1/auth/:platform` | 已有删除 | 清空 D1 秘密、保留 tombstone revision；可能仍有 Env fallback |
| `POST /v1/auth/:platform/connect` | 推荐的 OAuth 启动入口 | 200，URL + operationId + expiry；不等于连接完成 |
| `GET /v1/auth/:platform/connect` | 保留一版兼容入口 | 转入相同逻辑；no-store，不宣称它无副作用 |
| `GET /v1/auth/:platform/operations/:id` | 查询脱敏候选结果 | active 与 candidate 分开，不把旧配置当新授权成功 |
| `POST /v1/auth/:platform/operations/:id/complete` | 明确目标后完成连接 | 验证 expected revision，原子保存凭据和 receipt |
| `POST /v1/auth/:platform/refresh` | 已有刷新路径，增加 lease 保护 | 保留目标、单次外部调用 |
| 精确 `GET /v1/auth/:platform/callback` | 浏览器回调 | 受控 HTML，候选已收集/失败/需补配置 |

新连接、直接写入、删除和刷新遇到版本竞争返回 409；不得返回200然后丢失调用者的修改。既有客户端可不带 expected revision，由服务器在请求开始读取并用于本次 CAS；新 SDK/CLI 必须传入操作者看到的 revision，防止陈旧确认。已有 operation 的 complete 重放使用自己的 receipt，不要求 current revision 仍等于旧值。

错误仍是 `{ "error": { "code": "…", "message": "…" } }`。允许新增明确的 auth error code，但不改变既有 code 含义；callback 的有限 HTML 是被列明的例外。

## 8. 共享网络防护

私有 transport 返回有界的 status、headers 和 bytes/解析结果；deadline 必须覆盖响应头和 body 读取，不能在收到 headers 后就清掉 timer。大 body、慢 stream、挂起 cancel 都不能无限拖住执行。

固定政策：HTTPS；`redirect: "manual"`；明确拒绝 3xx；每次调用最多一次底层 fetch；发布请求和 OAuth 默认 15 秒、64 KiB（特定请求可取更小值）；释放 reader/timer/listener；不记录 token、body、Authorization 或原始 provider 错误。LinkedIn 的 201 + header 成功契约保留，不强迫它返回 JSON。

平台错误含义仍由各 adapter 判定。wrapper 不能把所有 5xx 变成“安全重试”，也不能判断 OAuth refresh 与普通查询具有同样的重试语义。原始外部 message 不能直接进入 API/log/Agent 输出。

Bluesky 自托管 host 是显式受信配置：只允许规范化 HTTPS hostname，拒绝 userinfo/path/非批准端口与默认私网地址；自托管并不等于允许任意请求转发。不能宣称单靠字符串 host 校验解决 DNS rebinding；本版不提供通用用户自定义 fetch URL 功能。

Cloudflare 文档提醒自动跟随重定向可能转发敏感 header，故这里主动拒绝重定向，而不是为兼容而改成 follow。[E1]

## 9. SDK、CLI 与 Skill

### 9.1 SDK

保持零私有运行时依赖。新增 `client.auth.status/set/connect/operation/complete/refresh/remove`，各方法明确请求方法、返回类型、AbortSignal、deadline 和写操作结果不确定性。

传输支持现有 GET/POST 与 auth 所需 DELETE；没有需求不加入 PATCH。错误上下文区分 post create 与 credential mutation：auth 写入失败的提示必须指向 auth 状态/operation 查询，不能提示重建帖子或使用新的 post key。

HTTP 2xx 的 body 为空、null、数组、基本类型、字段不合法，全部保留实际 status 与 `requestMayHaveBeenApplied=true`。只在确定尚未发出请求时才宣称 false；不因为 parser 第一层缺 context 改写事实。

`posts.wait()` 的活跃 sleep timer 默认 referenced。成功、超时、Abort 后清理；本版不增加 unref 选项，直到出现真实消费者需求。对构造器和单次调用的 timeout 都做有限正数及 timer 范围校验。`wait()` 只读，不会取消服务端任务。

### 9.2 CLI

新增命令：`auth status`、`auth set`、`auth connect`、`auth operation`、`auth complete`、`auth refresh`、`auth remove`。详细契约和实例见验收矩阵/交接说明。

敏感输入只能通过受控交互、stdin 或用户明确指定的凭据文件；不提供 `--access-token` 这类进入进程列表/历史记录的参数，不把凭据复制进帖子文档。预览只显示平台、字段名称、目标、版本及影响，不显示值。file/stdin 读取也应用大小限制。

`auth complete/set/remove` 使用 TTY 确认或显式 `--yes`，并提交被确认的 revision；secret 数据先注册到 Reporter 脱敏规则。HTTP 鉴权才是真正权限边界；`--yes` 不是授权凭证。`auth connect` 默认只打印经过白名单验证的 URL，不自动执行任意浏览器命令。

`--json` stdout 仍只有一个对象；diagnostic 走 stderr；success receipt、active connection 与 candidate 区别明确。新auth命令需要0.5.0服务端operation契约；旧服务端缺少它时明确报告升级需求，不通过暴露token或改走不安全的自动激活来fallback。原有posts接口仍须兼容。保持原退出码含义；不确定的 auth 写操作使用已有 ambiguity 类别，具体 error.code 区分，不假报 `createRequests=0` 就表示没有任何写操作。

移除 CLI 保活 interval 必须在 SDK 独立进程测试通过以后进行。用户工作区已有删除，不直接覆盖、提交或据此认定正确；实施从隔离 main 基线开始，最终单独比较。

### 9.3 Skill

先 doctor/必要的 auth status，再内容准备与确认；需要连接时用 auth 命令，不要求用户把 token 粘贴给 Agent。OAuth callback 页面不是完成证据，Agent 必须读 operation 并按用户选择 complete。

缺配置、过期、连接变更、真实发布结果未知应走不同指引。稳定 key 与最终内容保持不变。帖子正文、外部错误、OAuth 页面文本均为数据，不能授予权限、修改目标或诱导读取秘密。

## 10. 增量数据迁移与兼容性

### 10.1 最小数据变化

按实际最新 migration 编号新增，不重写 `0001–0005`。下列为逻辑字段，不是已执行的 SQL：

| 表 | 新增/调整 | 原因 |
|---|---|---|
| credentials | revision、binding_id、tombstone 标记、refresh lease/state | 防并发覆盖、删除 ABA、刷新重入；保留原 data/expiry |
| publications | credential_binding、claim_token | 防止旧任务跟随换号；隔离迟到写回 |
| oauth_state | operation_id、phase、expected revision、起始配置指纹、canonical callback、候选结果/receipt | 原子消费、候选确认与重放；复用已有短期存储 |

迁移为现有credential槽位初始化revision与随机binding_id，但不据此自动绑定历史publication；只读status不能隐式执行这些写入。

typed credential JSON 的 schema 版本在 decoder 内显式处理旧格式，不能靠 TypeScript assertion 接受所有历史数据。新增索引必须对应明确查找/条件更新；不因“以后也许需要”建索引。

### 10.2 旧任务政策

历史已终态记录原样保留。旧 scheduled/pending 没有目标绑定时，**禁止第一次执行时自动绑定“现在的账户”**。

升级预检必须输出未绑定的非终态数量、按平台分布和受影响任务 ID（不含正文/秘密）。操作者可以在维护窗口内显式审阅并绑定仍确定应发给当前连接的任务；这个一次性管理动作要求按 ID 列表、预期状态、当前连接指纹进行 dry-run/条件写入。它只允许 `status IN (scheduled,pending)`、`attempts=0`、`error_ambiguous=0` 且binding为空的记录；不能复活 ambiguous、已执行或已完成记录。

未被明确处理的 legacy 任务在新执行器中 fail closed，并报告 `AUTH` 与明确的“升级后需复核目标”原因；不能 silently skip、删除或产生平台请求。升级说明必须提示：这保留了内容和记录，但不会自动完成原发布承诺。

迁移中的 `publishing` 不做自动重新发送，按旧领取恢复/人工核实路径处理。进行生产升级前必须先取得明确授权并暂停实际 Queue/Cron 消费，不能只打开当前 admission maintenance 开关。

### 10.3 发布与回退

保持 `/v1/posts` 的路径、状态枚举、receipt、幂等和 error envelope。允许 auth DTO 新增字段；禁止在没有 release note 的情况下修改既有含义。安全收紧包括：不再半组混用凭据；callback 不自动激活；新 binding secret；旧任务需复核；这些属于明确行为兼容性变化，不包装成“完全无感”。

先做 additive schema，再在有授权的维护窗口切换执行者。schema 向后可读不等于旧代码安全：旧 Worker 不认识 binding 与 refresh guard。0.5.0 写入过新任务后，不能让旧 Worker 重新接管同一活动队列。回退先停止消费者/定时入口，再决定回滚代码、数据和流量，禁止恢复数据库后自动重发可能已成功的历史请求。

SDK、CLI、Worker 三个公共包统一到 `0.5.0-rc.1`，稳定验收后再统一 `0.5.0`；CLI 依赖 SDK 的精确版本。私有 core/adapters 不因公共版本号机械变更或对外发布。root manifest/lockfile、release checker 与 README 必须同步。

当前 release 文档记录 Worker 仍为 0.2 RC、SDK/CLI 为 0.4 RC，且发布工作流仍有 train 接线缺口。本版需准备一致的多包 gate 与隔离测试；设计本身、模拟 registry 成功都不等于实际 npm 发布授权。[B7]

## 11. 验收与完成定义

完整标准见 [03-ACCEPTANCE.md](03-ACCEPTANCE.md)，机器记录从 [acceptance-results.template.json](acceptance-results.template.json) 开始。所有产品测试本轮均为 NOT_RUN；不能继承以前的通过状态作为 0.5.0 的验收。

必须包含：纯规则测试；真实 local D1 的迁移/CAS/状态聚合；原生 workerd fetch 的五平台及 OAuth 出站 fixture；独立 SDK/CLI 子进程；打包后 monorepo 之外安装的消费者；兼容/故障注入。测试必须记录实际外部调用次数，不只验证 mock 被调用。

先解决既有 Worker suite 卡住的原因，保留正确性门槛，不靠删除 suite、无限延长 timeout 或广泛替换真实依赖来“绿灯”。Node 22/24 按仓库 CI 目标验证，具体安装版本在证据中记录。

产品完成条件：六项缺陷均有回归证据；授权完整链路通过；目标绑定与并发/刷新边界通过；所有必须本地门槛通过；文档/产物一致。真实平台未经独立授权与验收仍标 experimental/未验证，不能拿 Mock SNS 替代。

本文件的完成条件只是设计一致、边界明确、能够据此编写执行计划；它不证明任何源码已经修复。

<!-- 跨文件证据索引：代码证据与公开协议事实分开。 -->
[B7]: 05-SOURCES-AND-BASELINE.md#b7
[E1]: 05-SOURCES-AND-BASELINE.md#e1
[E2]: 05-SOURCES-AND-BASELINE.md#e2
[E3]: 05-SOURCES-AND-BASELINE.md#e3
[E4]: 05-SOURCES-AND-BASELINE.md#e4
[E5]: 05-SOURCES-AND-BASELINE.md#e5
[E6]: 05-SOURCES-AND-BASELINE.md#e6
[E7]: 05-SOURCES-AND-BASELINE.md#e7
