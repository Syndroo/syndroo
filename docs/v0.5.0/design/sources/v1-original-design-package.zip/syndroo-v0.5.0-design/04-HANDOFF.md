# Syndroo 0.5.0 — 实施准备与交接任务包

日期：2026-09-21。状态：**设计后续的准备材料，不是已批准的逐步执行计划，更不是实施完成报告**。

用户已确认 B 范围，并补充现有架构的合理抽象与设计模式优化；本轮只要求产出文件，取消了 OpenCode 模型前置要求。下面的代码修改、分支、迁移和测试都没有在本轮执行。

## 1. 下一工作会话先读什么

依次读取 [主设计](01-DESIGN.md)、[架构决策](02-ARCHITECTURE-DECISIONS.md)、[验收矩阵](03-ACCEPTANCE.md)与 [基线依据](05-SOURCES-AND-BASELINE.md)。恢复到当前仓库时，还要读取 README、AGENTS、相关包 manifest、邻近测试及已有进度记录。

本文件给出可执行计划所需的输入、任务边界和成功条件。正式实施前先评审书面规格，再据此生成详细执行计划；没有授权时不得把这些准备材料当作代码写入或外部发布许可。

## 2. 基线与不能遗漏的现状

- 已核实 main：`d8206f298333eeb83d45d319ea244bbda72c78f7`。
- 当前唯一用户本地改动：`packages/cli/src/main.ts` 删除保活 interval 与清理，共3行。本轮没有修改或接受它。
- 实施必须使用隔离 worktree，不能 reset/clean/stash 覆盖用户目录。不以工作区文件替代 committed-main 回归基线。
- 以前 Worker 测试在 Node26/Node24 都曾卡住；原因尚未得到本轮验证。它不是一个可跳过的测试集。
- SDK/CLI/Worker 公共包版本在基线不一致；发布列车和 npm 真实发布状态需在发布准备阶段分别检查，不能推测。
- 本次只产出会话附件，没有向仓库加入这些文件，也没有执行新 schema、新配置或产品修复。

## 3. 任务依赖与允许的并行

```text
规格评审 → 详细执行计划
    → T0 基线/测试门槛
        ├─ T1 共享传输与平台边界
        └─ T2 凭据/绑定/持久化契约
              → T3 发布执行状态机
              → T4 OAuth/refresh 生命周期
        → T5 SDK/CLI/Skill（服务端契约稳定后）
        → T6 集成、升级、版本和交付审查
```

这是依赖图，不是要求每项拆独立PR或派一个代理。最多两个 active 子任务；需要修改同一文件时必须串行或重新划分所有权，尤其 `repository.ts`、`platform-descriptors.ts`、core 类型、root manifests/lockfile 和 CI。

以下任务表中的 allowed files 是阶段性授权候选，只有真正开始该任务时才分配。不能因为清单里存在该路径就越过本次“只产出文件”的限制。

## 4. 交接任务合同

### T0 — 基线和可靠的验证环境

**目标：** 在隔离基线上复现六项问题，并使 Worker 本地测试能正常启动或明确定位真实阻塞。

**输入：** 05 的 F01–F06历史证据、AGENTS、`packages/cloudflare-worker/vitest.config.ts`、`test/setup.ts`、现有E2E harness。

**候选文件范围：** 测试启动配置、`docs/testing.md`、必要的测试环境辅助代码。不得删掉业务断言、把整个fetch替换为mock以消除workerd错误，或读取真实.dev.vars。

**产出：** 实际 Node/依赖版本、可重复执行的命令、失败回归fixture、阻塞根因与最小改法。环境变量必须采用fake值，端点只指向隔离服务。

**验收：** PKG-02；六项失败有可重演输入；不把超时当作实际断言失败或通过。

### T1 — 有界 transport 与平台 adapter

**目标：** 提取真实共用的网络防护，修复三平台运行时不兼容，保持平台自己的内容/成功/错误语义。

**输入：** 主设计第3、8节；ADR-050-02/09；各平台现有源码及测试。

**候选文件范围：** `packages/transport/**`、`packages/{bluesky,threads,x,tumblr,linkedin}/src/**` 与对应测试。root build/lockfile仅由集成负责人合入，不与T2并行修改。

**约束：** no follow redirects、no automatic write retry；deadline覆盖body；不新增第三方HTTP库；不公开private包；Publisher构造零SNS请求。typed credential的字段契约在修改前交给T2确认。

**产出：** 可复用函数及所有实际调用者迁移、原生workerd出站测试；不是只有一个helper但旧路径仍自行fetch。

**验收：** ARC-01/02、NET-01–05；F02回归通过。

### T2 — 统一解析、绑定与D1事务契约

**目标：** 建立唯一credential resolution，增加revision/binding/claim/schema基础，保持具体D1Repository。

**输入：** 主设计第4、6、10节；ADR-050-03/05/06/11；所有相关调用者和历史schema。

**候选文件范围：** Worker `credentials.ts`、`platform-descriptors.ts`、`repository.ts`、新migrations、相关数据库/解析测试；确有共享需要的core类型由协调者独占处理。

**约束：** 不引入泛型Repository/ORM；secret不出DTO/log；D1用户凭据整组选择；删除保留无秘密tombstone；binding key独立；SQL 0行不当成功；旧任务不能自动绑定当前账户。

**产出：** typed resolver及safe DTO、持久化方法契约、增量schema、迁移dry-run/fixture。涉及返回字段和新增HTTPcode要先冻结。

**验收：** ARC-03/04、CFG-01–04、BND-01–05、MIG-01/02；事务的逻辑guard与故障回滚均有真实localD1证据。

### T3 — 发布编排与幂等/错误阶段

**目标：** 准备在claim前完成，恢复正确的publication生命周期，解决F01/F03及并发写回问题。

**输入：** T2已冻结的resolver/repository契约；主设计第5节；现有jobs/retry/scheduler测试。

**候选文件范围：** Worker `api.ts`、`posts.ts`、`publishing.ts`、`retry.ts`、`jobs.ts`、必要scheduler调用点及相邻测试。对repository的新需求先回协调者，不和T4并行写同一文件。

**约束：** receipt重放不依赖当前平台配置；maintenance行为不偷偷改；claim后使用同一已准备Publisher；准备期故障不耗Publisherattempt；写回带claim token；未知结果不重发。

**产出：** 状态转移与调用序列回归测试；外部请求数证据；删除重复SQL retry算法。

**验收：** CRT-01–04、PUB-01–06；F01/F03通过。

### T4 — OAuth候选激活与refresh并发

**目标：** 完成候选结果→明确target→CAS激活；state只消费一次；refresh在外部请求前取得持久lease。

**输入：** 主设计第7节；ADR-050-07/08；T2的持久化契约；平台/app实际OAuth能力参考。

**候选文件范围：** Worker auth模块、protocol helper、相关route/DTO/测试。revision/事务若需更改由单一所有者执行。

**约束：** callback不覆写active；不能盲继承旧author；client secret与state从不进入日志；complete重复重放receipt不复活已删凭据；PKCE需要真实能力依据；超时refresh不能重用可能已旋转的旧token。

**产出：** 固定HTTP契约、operation状态/receipt、刷新/重连规则、无真实账户的OAuth出站fixture、兼容说明。

**验收：** AUT-01–08、REF-01–04；F05通过。

### T5 — 公共SDK/CLI/Skill

**目标：** 补齐授权入口，修复SDK错误上下文和独立进程wait，保持现有post安全流程。

**输入：** 冻结后的T3/T4 HTTP契约；主设计第9节；现有SDK/CLI测试与Skill规范。

**候选文件范围：** `packages/sdk/**`、`packages/cli/**`。SDK与CLI可在契约稳定后拆并行，但不能由两个写者改CLI共享参数/Reporter文件。

**约束：** SDK零私有runtime依赖；不依赖mono内部import；auth写入没有自动重试；token不是CLI参数；单JSON stdout；移除keepAlive的前提是独立进程行为测试而不是代码看起来更短。

**产出：** auth门面、真实CLI命令、safe input/output、Skill流程、子进程与tarball消费者测试。

**验收：** SDK-01–05、CLI-01–05、SKL-01–03；F04/F06通过。

### T6 — 集成、升级与发布准备

**目标：** 从空配置跑通完整链路；验证兼容/迁移；统一0.5.0候选版本与打包产物；产出可审查结果。

**输入：** 各任务实际结果、主设计第10–11节、现有release/testing文档及完整验收矩阵。

**候选文件范围：** `e2e/**`、`scripts/**`、`.github/workflows/**`、root manifests/lockfile、三个公共包版本字段、README/AGENTS/CHANGELOG和必要docs。不得修改另一个syndroo-web仓库。

**约束：** 本地fake registry/loopback；workflow修改也必须审查真实effects；实际npm发布/远端迁移/部署/发帖另行授权。原始用户工作区保持不动。

**产出：** 当前commit对应的验收JSON、日志与产物哈希；升级/回退runbook；明确的未验证平台与真实操作阻塞。

**验收：** 全部64项本地门槛，原项目仍适用的门槛。LIV-01/02无授权不得执行或标PASS。

## 5. 最终命令验证清单（未来执行，不是本轮日志）

先在隔离环境中确认每条脚本的真实内容及本地副作用；确保没有真实账户凭据。按项目要求运行相关迁移与聚焦回归，再执行：

```sh
npm test
npm run check
npm run bundle
npm run startup
npm run build:package
npm run e2e:local
npm run e2e:consumer -- --source tarball
npm run verify:package
npm run release:train
npm pack --workspace @syndroo/sdk --dry-run
npm pack --workspace @syndroo/cli --dry-run
npm pack --workspace @syndroo/cloudflare-worker --dry-run
git diff --check
```

`npm run release:train`须使用默认离线/fixture行为，不设置真实registry写入环境。`npm pack --dry-run`仍可能触发已声明生命周期脚本，需在隔离工作区执行；不能把dry-run等同于没有本地副作用。

现有 `e2e:live` 或带 `--remote` 的命令不在以上清单内。远端作用和任何真实账户操作必须单独计划、单独批准。不要把独立命令、commit、push、deploy串成一条一旦开跑就无法中途审查的链。

## 6. CLI拟议使用流程

以下是拟议契约，不是已经可用的0.5.0命令。示例值只用于fake fixture；不代表任何真实平台API版本仍受支持。

```sh
syndroo doctor --json
syndroo auth status --json
syndroo auth connect linkedin --json
# 用户在浏览器授权；此时只是candidate，不代表active已替换。
syndroo auth operation linkedin <operation-id> --json
syndroo auth complete linkedin <operation-id> \
  --file target.json --expected-revision 7 --yes --json
syndroo auth status linkedin --json

# 已有原始凭据时，从权限受控文件/stdin传入，禁止token flag。
syndroo auth set bluesky --file credentials.json \
  --expected-revision 0 --yes --json

# 发布流程继续保留稳定key和最终状态回读。
syndroo posts validate --file post.json --json
syndroo posts create --file post.json --yes \
  --idempotency-key release-050-example --json
syndroo posts wait <post-id> --timeout 60s --json
```

`expected-revision`来自实际status/operation，不可照抄示例。target文件只包含明确的非秘密author/blog/api_version选择；credential文件含secret，CLI不得回显，Agent也不应让用户把它作为聊天正文发送。

OAuth authorize URL不可替换成任意provider返回的跳转目标，必须验证预期origin。URL本身含协议必需的短时参数，只在受鉴权connect响应/明确用户交互中输出，不写通用日志或结果证据。

## 7. 进度、重试与最终回报

未来实施使用项目已有进度机制；没有则一个独占的 `scratch/v050-implementation/progress.md`，不覆盖其他任务。记录baseline、spec版本、已完成标准、修改文件、真实运行命令、子任务ID/次数、阻塞和下一步。

子任务首次执行计为1，最多3次；失败后必须改变输入/方法或观察到相关环境变化后再重试。等待超时不自动开启新写者。完成的子任务回报目标、改动、验证证据、尚未解决的问题，由架构负责人审核接受。

此次文件设计没有编码模型依赖，没有调用或替代任何OpenCode模型。后续选择执行模型时遵守当时明确指令、可用能力和权限，不沿用已取消的OpenCode预检阻塞，也不伪造已调用。

最终报告分别给出：源码是否完成、本地验收是否通过、安装产物是否验证、live是否获准/完成、是否实际发布。没有实际发布证据就不写“0.5.0已发布”。
