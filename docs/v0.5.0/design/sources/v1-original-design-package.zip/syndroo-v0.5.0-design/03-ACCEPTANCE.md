# Syndroo 0.5.0 — 验收矩阵与证据要求

日期：2026-09-21。**这是未来实施的验收要求，不是测试报告。所有产品条目当前均为 NOT_RUN。**

本矩阵对应 [主设计](01-DESIGN.md)。JSON模板与此表使用相同ID，由同一份条目数据生成。文件包自己的链接/JSON/编号检查只证明文档完整性，不证明这些产品条目已通过。

## 判定规则

- PASS：当前最终源码、实际命令与可检查的输出证明达到标准。读代码、stub声称成功、历史commit测试不能代替。
- FAIL：断言/行为不符；修正后必须对同一标准重新执行。
- BLOCKED：权限、运行时、未批准的真实账户动作等阻止执行。写清原因，不计入通过。
- NOT_RUN：尚未执行。本轮全部产品门槛处于此状态。
- SKIP：只有本次发布明确非适用且维护者记录理由的条件门槛可用；不能跳过本地安全/并发/迁移标准。

本地门槛全部通过只是开发验收；真实平台与实际npm/生产发布另有批准和既有项目门槛，不能自动视为完成。

## 测试层次和边界

纯函数测试检查解析/政策；local D1验证事务与CAS；workerd集成保留原生fetch、仅替换出站服务；独立子进程验证SDK/CLI生命周期；tarball消费者验证真实安装边界；live gate只在另外批准后执行。

所有本地网络仅允许literal loopback/mock。显式注入fake凭据，不能从真实.dev.vars或环境偷偷拿用户token。必须记录发布写请求数、token exchange数与被阻止的出站请求；超时后检查同一进程/任务，不启动重叠写者。对同一子任务至多三次执行尝试；无新证据不盲重跑。

## 六项历史缺陷追踪

| 缺陷ID | 历史问题 | 核心验收ID |
|---|---|---|
| F01 | D1授权与创建准入不一致 | ARC-03、CFG-01、CRT-01 |
| F02 | workerd redirect不兼容及mock掩盖 | NET-01、NET-02 |
| F03 | 发布前D1故障误判为远程不确定 | PUB-01 |
| F04 | SDK异常2xx丢失应用可能性上下文 | SDK-01 |
| F05 | OAuth/refresh覆盖目标元数据 | AUT-04、AUT-05、REF-02 |
| F06 | SDK/CLI独立进程等待提前结束 | SDK-03、SDK-04、CLI-04 |

总计 **66 项**：64 项本地开发门槛，2 项需单独授权的真实平台门槛。

## 架构

| ID | 通过标准 | 验证方法 | 必须留存的证据 |
|---|---|---|---|
| ARC-01 | core 不依赖 Worker/Cloudflare/平台/transport；SDK 不依赖私有包；依赖图无环。 | 静态 import/manifest 检查，并运行各包类型检查。 | import 检查结果、manifest diff、tsc exit code。 |
| ARC-02 | 平台差异由 typed strategy/adapter 表达；没有 BasePublisher/通用 DI/动态插件系统；构造 Publisher 零网络。 | 逐平台类型负例与构造 spy，review 所有实际 caller。 | 错误 credential 编译/decoder 失败证据，构造 fetch 次数=0。 |
| ARC-03 | auth 状态、创建准入和执行使用同一解析规则；不存在三套独立 configured 判断。 | 同一数据集覆盖三个入口；检索旧 helper caller。 | 三个入口的对照结果与完整替换点。 |
| ARC-04 | 只有 retry.ts 决定业务 retry_at，SQL 落实 guard；新增抽象均有真实消费者。 | 纯政策测试 + D1 retry_at 断言 + 结构 review。 | 政策输入/输出、SQL 持久值与新增模块消费者清单。 |

## 凭据解析

| ID | 通过标准 | 验证方法 | 必须留存的证据 |
|---|---|---|---|
| CFG-01 | env-only、D1-only、mixed 三条链路均能受理已配置的平台；D1-only指用户凭据仅存D1，必要app secret仍按规则由Env提供；可走到隔离平台成功。 | 真实 Worker/D1 + 假凭据 + 出站 mock；五平台表驱动。 | auth readiness、HTTP202、publication状态、实际出站计数。 |
| CFG-02 | 不混用不同来源的一组 user token；D1 损坏/缺字段/过期不静默回退 Env。 | 完整/部分/损坏/过期 fixture，与 Env 另一个账户并存。 | blocked原因、零持久帖子、零平台请求、无 token 日志。 |
| CFG-03 | null、数组、基本类型、非法字段、非法 author/blog/host/version/expiry 返回受控错误。 | 通过 HTTP auth endpoint 发送恶意/错误输入。 | 400/422及固定错误 envelope；没有未捕获TypeError或原始输入。 |
| CFG-04 | 公开 status 不包含秘密；source 反映实际来源，configured 不冒充 live verification。 | 成功/失败/expired/mixed响应契约测试。 | DTO字段与sentinel秘密扫描结果。 |

## 创建/幂等

| ID | 通过标准 | 验证方法 | 必须留存的证据 |
|---|---|---|---|
| CRT-01 | 相同 key+相同内容返回同一post；更改内容为409；凭据改变后仍能重放旧receipt。 | 真实 D1，先create再变更配置，重放/冲突；维护关闭。 | Post/Publication行数不增加，重放200，无第二次入队。 |
| CRT-02 | 并发同key请求仅保存一个完整Post及其平台publication集合。 | 并发HTTP调用和D1唯一键竞争；注入事务中途失败。 | 唯一记录、无部分平台集合、无孤儿、原子回滚证据。 |
| CRT-03 | 结构与平台配置失败均不产生部分写入；准入读取到的凭据被换号时事务不得接受旧快照。 | 在解析与D1创建之间插入revision变更。 | 0个新Post/Publication；明确冲突/拒绝，而非200/202。 |
| CRT-04 | 保持64KiB上限、授权和维护模式；排队失败保留可恢复pending。 | 超大body、无token、maintenance、Queue send异常fixture。 | 状态码、无越权/误写、enqueueDeferred和Cron恢复日志。 |

## 执行状态机

| ID | 通过标准 | 验证方法 | 必须留存的证据 |
|---|---|---|---|
| PUB-01 | credential read短暂失败发生在claim前，零attempt增加、零SNS调用、不进入ambiguous终态。 | 真实publication+D1故障注入，再恢复D1并执行。 | pending/attempts对照、最终可恢复、总发布次数1。 |
| PUB-02 | 并发重复投递只有一个claim winner；任何SNS请求都在claim之后。 | 并发消费者屏障；拦截session和publish出站顺序。 | claim token、时间顺序、平台写次数=1。 |
| PUB-03 | 真正可重试失败受retry_at和三次执行上限约束；Queue与Cron不绕过。 | 推进受控时钟，交错Queue重复消息与Cron。 | attempts不超过3，早到消息不发，retry_at持久化。 |
| PUB-04 | 平台已收到但响应丢失/超时/5xx时，记录不确定结果且永不自动重发。 | 出站stub记录请求后断开；重投Queue并运行Cron。 | errorAmbiguous=true，终态保留，总远程写次数1。 |
| PUB-05 | 平台成功或失败后D1落库失败，不导致第二次平台调用；父Post与Publication不部分更新。 | SQL失败触发器/隔离数据库注入。 | 事务回滚，后续delivery不重发，最终保守恢复结果。 |
| PUB-06 | stale recovery、旧claim token、迟到provider结果不会覆盖较新/终态数据。 | 受控时钟与顺序屏障，执行条件写回。 | 旧token更新0行、终态不变、脱敏late-result诊断。 |

## 目标绑定

| ID | 通过标准 | 验证方法 | 必须留存的证据 |
|---|---|---|---|
| BND-01 | D1 A→B、D1删除回Env、Env token/host/author/app变化都不能使旧任务发到新目标。 | 每种变更后执行旧scheduled/pending。 | AUTH且非ambiguous、零SNS请求；新任务可用新binding。 |
| BND-02 | 同grant受控refresh保留target/binding，直接重设和OAuth重连总是建立新binding。 | 比较操作前后revision/binding及旧任务行为。 | refresh后正常；重连后旧任务拒绝，秘密不出现在差异日志。 |
| BND-03 | claim前凭据竞争被CAS挡住；claim后重连不把已有Publisher改成新token。 | 精确在claim前/后切换，记录出站sentinel账号。 | preclaim零发；postclaim最多使用原快照，绝不发到新账户。 |
| BND-04 | 独立binding key缺失/非法时新发布fail closed；API key轮换不改binding；binding key更换需复核。 | 配置矩阵+未完成任务fixture。 | 拒绝原因、binding连续性、不存在默认key/绕过路径。 |
| BND-05 | legacy无绑定任务不会自动绑定当前账号；删除再创建不复活旧revision或旧OAuth确认。 | 旧schema fixture，credential删除/重建/complete交错。 | 原ID/content/key保留、零误发、旧revision更新0行。 |

## OAuth

| ID | 通过标准 | 验证方法 | 必须留存的证据 |
|---|---|---|---|
| AUT-01 | 只有精确callback可免Bearer；额外路径段、未知平台、错误method不扩大授权例外。 | 路由表驱动、安全负例。 | 401/404/405与零未授权D1写入/外部请求。 |
| AUT-02 | callback使用已保存canonical URL和平台配置；拒绝错误state/平台/expiry/OAuth1 token。 | 篡改callback参数、Host、app配置与时间。 | 无token exchange、固定错误页、原active未改变。 |
| AUT-03 | 同一state并发callback仅一个进入exchange；崩溃或失败不能重置state重用。 | 真实D1 CAS+并发callback+中断。 | token endpoint调用次数1；operation phase正确。 |
| AUT-04 | callback不覆盖active；缺LinkedIn author/Tumblr blog时显示候选需配置，不复制旧目标。 | A活动连接、B候选令牌、目标缺失fixture。 | 旧凭据未变，candidate phase与missingFields明确。 |
| AUT-05 | complete需要Bearer、明确target、正确revision；凭据激活与operation receipt原子提交。 | 正常/竞争/事务失败/未授权complete。 | 成功一次或全不变；冲突409；无half-completed状态。 |
| AUT-06 | 重复complete只重放该operation的receipt；不能覆盖之后的direct set/delete。 | complete→后续credential变更→重复complete。 | 零额外exchange、当前槽位保持较新值，receipt标记replayed。 |
| AUT-07 | OAuth1编码与签名具标准测试向量；OAuth2的PKCE设置有平台/app证据且不静默降级。 | 编码特殊字符向量、假授权服务器校验、配置审查。 | 签名相等，支持的S256参数匹配；未证明能力不声称已支持。 |
| AUT-08 | 操作结果与HTML无code/state/token；no-store/no-referrer/CSP；过期候选秘密按期限清理。 | sentinel扫描、header断言、Cron/过期状态测试。 | 零秘密泄露、到期候选不可complete、清理不误删active。 |

## 刷新

| ID | 通过标准 | 验证方法 | 必须留存的证据 |
|---|---|---|---|
| REF-01 | 并发refresh在外部请求前获得D1 lease；只有一个winner请求平台。 | 同revision两个refresh并发，通过真实localD1。 | token endpoint总次数1；loser409，非进程内锁。 |
| REF-02 | refresh保留author/blog/api_version与binding；正确处理expires_in和refresh token轮换。 | 缺失/更新/非法refresh token与expiry响应矩阵。 | 只替换允许token字段、revision递增、旧目标未丢失。 |
| REF-03 | 网络结果未知、崩溃或保存失败不重用可能已旋转的refresh token。 | 外部收到后断开，推进60秒lease窗口与重试请求。 | reconnect_required、外部总请求仍为1、旧token不自动再发。 |
| REF-04 | refresh与direct set/complete/delete交错，旧refresh结果不能覆盖新连接。 | 响应屏障+revision和lease token竞争。 | 新连接保留、旧写回0行，无binding降级。 |

## 传输

| ID | 通过标准 | 验证方法 | 必须留存的证据 |
|---|---|---|---|
| NET-01 | 五平台与OAuth使用原生workerd fetch通过隔离出站服务，不用fetch mock替代运行时验证。 | 生产bundle+localworkerd+fail-closed outbound fixture。 | 真实原生参数可执行；每平台成功信号与结果正确。 |
| NET-02 | 301/302/303/307/308都不跟随，目标server收到零Authorization/body请求。 | 两个loopback服务，第一跳返回重定向。 | 第二跳请求次数0，write结果保守分类。 |
| NET-03 | deadline覆盖headers与body；超大/慢流/中断/cancel挂起均有界结束。 | 真实stream/fault fixtures，有限外部test watchdog。 | 耗时上限、reader/timer/listener清理、无泄漏事件。 |
| NET-04 | 共享transport不重试、不解释业务；官方SDK额外写重试保持关闭。 | 429、5xx、超时、SDK parsing失败组合。 | 单次adapter尝试最多一次发布写请求；已声明session步骤除外。 |
| NET-05 | provider原始错误/凭据不经日志、异常cause序列化或API返回泄露。 | 在URL/header/body/error中放fake sentinels。 | stdout/stderr/Worker日志/DTO/snapshot全部扫描为零。 |

## SDK

| ID | 通过标准 | 验证方法 | 必须留存的证据 |
|---|---|---|---|
| SDK-01 | HTTP2xx receipt为空/null/数组/基本类型/缺字段时保留实际status与mayHaveBeenApplied=true。 | SDK public create对坏响应表驱动测试。 | 每一形状的error字段；无自动重发。 |
| SDK-02 | 区分未发送Abort、在途Abort、网络不确定和服务拒绝；post/auth提示指向正确恢复入口。 | public API fake server，写操作计数。 | context与错误消息正确、无post key误用于auth刷新。 |
| SDK-03 | 独立Node进程wait在queued之后会继续轮询并settle，而不是提前退出。 | 单独child process，不放保活interval；先pending再terminal。 | 至少两次读取、Promisesettled、退出码与结果正确。 |
| SDK-04 | 成功/超时/Abort后进程能退出；timeout非法/溢出受控拒绝。 | 独立进程+有限父进程watchdog，多结局fixture。 | 无悬挂句柄/未处理拒绝；退出未依赖强制kill。 |
| SDK-05 | auth status/set/connect/operation/complete/refresh/remove都使用薄门面，写不自动重试。 | 安装后的SDK对隔离Worker调用。 | 正确HTTP方法/DTO/错误code与调用次数。 |

## CLI

| ID | 通过标准 | 验证方法 | 必须留存的证据 |
|---|---|---|---|
| CLI-01 | auth完整命令链可从无配置到已激活连接，再到post结果；candidate与active分开。 | 真实CLI child+隔离Worker/OAuth/SNS。 | 每条命令输出/退出码与服务端记录对应。 |
| CLI-02 | secret通过stdin/文件/受控输入；无secret命令行flag；预览/log/JSON不输出秘密。 | 非交互文件/管道/非法文件/超大输入+sentinel扫描。 | 进程argv、stdout/stderr、持久文件无秘密泄露。 |
| CLI-03 | 需要确认的set/complete/remove在取消或缺yes时零写；陈旧revision不会覆盖。 | TTY与非交互两组真实进程。 | 退出码、写请求次数0或受控409。 |
| CLI-04 | SDK修复后移除保活workaround仍可wait；每个JSON命令stdout恰好一个对象。 | 独立CLI进程，queued→terminal与timeout/Abort。 | stdout可单次JSON.parse，stderr独立，settle/退出正确。 |
| CLI-05 | 保持原post validate/dry-run/create/get/list/wait契约，稳定key、冻结内容和取消行为不退化。 | 现有CLI/SDK测试与consumer gate。 | 原测试结果、发布请求数与预览输入哈希相同。 |

## Skill

| ID | 通过标准 | 验证方法 | 必须留存的证据 |
|---|---|---|---|
| SKL-01 | Agent通过CLI完成授权指引和确认，不索取聊天中的token，不把callback当发布成功。 | 固定fake trace/eval与规则契约测试。 | 命令顺序、用户确认点、秘密值不进入会话。 |
| SKL-02 | 正文/provider错误/OAuth页面注入不能修改目标、读取秘密、调用额外工具或授予授权。 | 恶意文本fixture与既有Skill合同测试。 | 零越权写、原内容/target/key保持，明确停止原因。 |
| SKL-03 | 未配置、过期、连接变更与ambiguity指引不同；无工具时不伪造完成。 | 离线流程fixture及HTTP fallback合同测试。 | 明确状态、无换路重发/新key、限制说明。 |

## 迁移

| ID | 通过标准 | 验证方法 | 必须留存的证据 |
|---|---|---|---|
| MIG-01 | 只新增migration，不改已应用0001–0005；fresh和upgrade两个路径均成功。 | 一次性localD1分别空库迁移和旧schema升级。 | migration列表、schema对照、旧数据行数。 |
| MIG-02 | 旧终态/幂等结果保留；无绑定pending/scheduled默认零发且明确需复核。 | 含旧Post、ambiguous、publishing的fixture。 | 原ID/content/key保留；无自动复活或默认重绑。 |
| MIG-03 | 显式legacy绑定管理只处理列出的未执行任务；dry-run零写，陈旧状态/绑定被拒绝。 | 仅一次性localD1，按ID和expected状态/指纹操作。 | dry-run报告、准确影响行数、无外部请求。 |
| MIG-04 | 升级/回退runbook明确停止Queue/Cron、等待in-flight，不把maintenance当消费者暂停。 | 静态runbook审查+本地模拟cutover，无生产调用。 | 操作前置条件、回退禁止旧worker混跑和重发的检查点。 |
| MIG-05 | secret/vars/migration变化同步例子、bindings、generated types、deploy helper与文档。 | 配置生成及独立临时部署模板build检查。 | 无真实secret/D1ID进入产物；部署准备失败有明确原因。 |

## 构建/发布准备

| ID | 通过标准 | 验证方法 | 必须留存的证据 |
|---|---|---|---|
| PKG-01 | 三个公共包统一0.5.0-rc.1及CLI精确SDK依赖；private包保持private。 | release-train离线验证、manifest/lockfile检查。 | 版本一致、public/private依赖闭合。 |
| PKG-02 | 现有Worker suite卡住问题已定位并解决，不删suite/弱化mock换取通过；Node22/24验证。 | 干净隔离工作区、明确fake secret配置、有限测试时间。 | 真实test数量/退出码/运行时版本；无遗留进程。 |
| PKG-03 | npm test/check/bundle/startup及脚本测试全部有当前源码的成功证据。 | 按项目命令执行，不混入用户未提交修改。 | 命令、commit、exitcode、日志、测试数量。 |
| PKG-04 | monorepo外安装tarball后的SDK/CLI/Worker功能和授权链路通过。 | e2e:consumer、verify:package、三个npm pack dry-run。 | resolved包路径、tarballsha、功能结果；没有私有包registry依赖。 |
| PKG-05 | 多包发布顺序/RC tag/部分失败恢复在fake registry验证；真实发布仍独立授权。 | release-train/check-release和workflow离线fixture。 | SDK→CLI→Worker计划；不重复已发布包；非404不当成缺包。 |
| PKG-06 | README/AGENTS/Skill/CHANGELOG与代码一致，清楚写明新secret、callback变更、legacy限制。 | 链接/例子/命令合同与最终diff审查。 | 无过时“仅Worker公开包”或“所有v1含callback需Bearer”等矛盾。 |

## 真实平台

| ID | 通过标准 | 验证方法 | 必须留存的证据 |
|---|---|---|---|
| LIV-01 | 保持当前发布政策要求的真实平台账户验收，不用mock替代发布权限/身份/API能力验证。 | 另行批准的staging+内容/账户/数量明确的live plan；默认不执行。 | 批准记录、平台可核查结果、实际路由/版本；缺授权记录BLOCKED而非PASS。 |
| LIV-02 | 真实OAuth/refresh能力按平台与app验证；未验证的集成明确experimental。 | 独立有授权的账户计划，包含callback/目标/expiry检查。 | provider/app能力证据、验证日期、未完成限制，不保存秘密。 |

## 结果记录格式

执行者复制 `acceptance-results.template.json` 为本次具体结果文件，逐项填入：status、实际命令、exit code、源码commit、Node/workerd/相关依赖版本、证据路径、失败/阻塞说明。复跑记录不能覆盖掉先前失败原因；可在evidence数组追加每次结果。

最终验收须基于将交付的确切源码。任何影响被测代码的后续修改都会使相关结果需要重验。不得用“0 tests”冒充PASS，也不得用本文件包的document-validation.json填充产品验收证据。

## 设计阶段自审结论

本矩阵已经覆盖六项历史缺陷、授权激活/刷新并发、连接绑定与legacy迁移、真实fetch边界、公共包依赖和Agent误报。设计尚未获得实现验证；SQL具体写法、平台应用权限与真实运行时行为仍需按上述方法给出证据。
