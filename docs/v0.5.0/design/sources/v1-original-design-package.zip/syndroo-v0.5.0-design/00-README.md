# Syndroo 0.5.0 设计文件包

**版本定位：可靠性修复 + 授权闭环 + 有依据的架构优化。**

日期：2026-09-21。基线：`main@d8206f298333eeb83d45d319ea244bbda72c78f7`。

用户已经确认推荐B范围，并要求使用合理抽象/设计模式让代码更健壮、易维护。本包将这一要求落实为可评审的书面规格，而不是只提供模式名称或笼统重构建议。

**这是一套设计附件，不是已经实现的0.5.0。** 没有修改仓库产品代码，没有执行迁移、部署、发布或真实SNS请求；没有编码模型调用。用户原有CLI未提交修改仍保持不动。

## 文件导航

| 文件 | 内容 |
|---|---|
| [01-DESIGN.md](01-DESIGN.md) | 主规格：范围、架构、配置规则、发布状态机、绑定、OAuth、SDK/CLI、迁移兼容 |
| [02-ARCHITECTURE-DECISIONS.md](02-ARCHITECTURE-DECISIONS.md) | 12条ADR：备选、选择、模式适用边界、复杂度成本与验证方法 |
| [03-ACCEPTANCE.md](03-ACCEPTANCE.md) | 66项验收：64项本地门槛、2项另行授权的真实平台门槛 |
| [04-HANDOFF.md](04-HANDOFF.md) | 后续实施准备：任务依赖、输入、文件归属、验收、验证命令和回报要求 |
| [05-SOURCES-AND-BASELINE.md](05-SOURCES-AND-BASELINE.md) | 当前源码位置、历史复现限制、外部一手协议/运行时资料 |
| [acceptance-results.template.json](acceptance-results.template.json) | 与验收表同ID的机器结果模板，全部为NOT_RUN |
| [document-validation.json](document-validation.json) | 仅本文件包的完整性/一致性校验结果，不是产品测试报告 |

先看主规格第1、3节，再看第6、7、10节的行为与升级成本；详细任务启动前以主规格和验收表为准。

## 方案的核心

保留Cloudflare上的模块化单体，不拆微服务、不建设通用插件或DI框架。平台差异用Adapter/Strategy；平台选择用静态构造；业务编排用明确的应用函数；发布转移用有限状态机和SQL guard；D1Repository与publication-outbox继续使用；SDK/CLI作为稳定门面。

真正要集中的是**规则**，不是把所有代码塞进一个万能抽象：凭据只解析一次、网络防护只维护一套可复用政策、重试决策只有一个来源、远程结果不确定性不在层间丢失。

## 必须在评审时看到的取舍

**新配置。** 引入独立 `SYNDROO_BINDING_KEY` 保护任务连接连续性；OAuth需要canonical `SYNDROO_PUBLIC_URL`。这会增加升级准备，不是完全无感升级。

**OAuth行为。** 浏览器callback产生候选结果，用户通过受鉴权complete明确目标后才激活；不能继续把callback的200等同于连接已生效。

**换号与旧任务。** direct set/重新授权默认改变binding，旧任务不会静默转投新账号；同grant受控refresh可以保留binding。无法证明同号时选择停止自动执行，而不是猜测。

**历史数据。** 没有绑定的旧pending/scheduled任务需要显式复核；不会自动绑定当前账户。additive schema不意味着旧Worker可以安全重新接管新任务。

**不扩张为C范围。** 完整凭据加密/自动密钥轮换、多账户产品、调度扩容和指标平台仍不在本版。B内只加入兑现安全行为所必需的绑定、CAS、临时操作状态和迁移保护。

## 当前完成状态

| 项目 | 状态 |
|---|---|
| B范围确认 | 已确认 |
| 架构/行为规格与ADR | 已形成，待评审 |
| 实施准备与验收标准 | 已形成 |
| 详细执行计划及执行方式 | 书面规格评审后的步骤，本轮未启动 |
| 产品代码修改/新测试/迁移 | 未执行 |
| 产品验收 | 66项全部NOT_RUN |
| 真实平台/正式发布 | 未授权执行、未执行 |
| 文档附件完整性检查 | 见document-validation.json，不替代上述验收 |

此包可作为未来 `docs/v0.5.0/` 的内容基础，但本轮没有复制进仓库。实施会话必须先核对最新HEAD、用户修改、当前规则及既有进度，不把这里的旧baseline当成永远最新。
